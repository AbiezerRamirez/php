<?php
$mensajes=array(
    1=>"El alias ya existe, debes elegir otro",
    2=>"Error, ya existe otro usuario con ese DNI",
    3=>"Registrado correctamente",
    4=>"Error, el alias y la contraseña no coinciden",
    5=>"El alias actual no coincide",
    6=>"El nuevo alias es demasiado corto",
    7=>"Los dos alias no son iguales",
    8=>"Las dos alias nuevos no pueden estar vacías",
    9=>"El alias es muy corto debe tener 4 caracteres",
    0=>"Alias cambiado correctamente",
    17=>"Notas cambiadas correctamente",
    18 => "El usurio y/o la contraseña no son correctos",
    19 => "Error al mover el archivo al servidor",
    20 => "Errror: Debes elegir un archivo de imagen adecuado",
    21 => "Imagen cambiada correctamente"
   );

?>