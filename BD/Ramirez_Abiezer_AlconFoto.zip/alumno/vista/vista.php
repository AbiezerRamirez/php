<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Mi CSS personal -->
    <link href="vista/miestilo.css" rel="stylesheet">
    <!-- Para lo que no he modificado yo -->
    <link href="vista/plantilla.bootstrap.css" rel="stylesheet">
    <title>Gestión de Alumnos</title>
</head>

<body class="text-center">


    <div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
        <header>
            <h2 style="margin-bottom: 1em;">Bienvenido <?php echo $_SESSION['user']; ?></h2>
            <div>
                <h3 class="float-md-start mb-0">Listado de alumnos. Grupo de DAW2</h3>
            </div>
        </header>

        <hr>

        <main role="main" class="inner cover">
            <div>

                <form action="?action=<?php echo $alumno->id > 0 ? 'actualizar&foto=' . $alumno->__GET('Fotografia') : 'registrar'; ?>" method="post" style="margin-bottom:30px;" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $alumno->__GET('id'); ?>" />

                    <table style="width:500px;">
                        <tr>
                            <th style="text-align:left;">Nombre</th>
                            <td><input type="text" name="Nombre" value="<?php echo $alumno->__GET('Nombre'); ?>" style="width:100%;" /></td>
                        </tr>
                        <tr>
                            <th style="text-align:left;">Apellido</th>
                            <td><input type="text" name="Apellido" value="<?php echo $alumno->__GET('Apellido'); ?>" style="width:100%;" /></td>
                        </tr>
                        <tr>
                            <th style="text-align:left;">Sexo</th>
                            <td>
                                <select name="Sexo" style="width:100%;">
                                    <option value="1" <?php echo $alumno->__GET('Sexo') == 1 ? 'selected' : ''; ?>>Masculino</option>
                                    <option value="2" <?php echo $alumno->__GET('Sexo') == 2 ? 'selected' : ''; ?>>Femenino</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th style="text-align:left;">Fecha</th>
                            <td><input type="text" name="FechaNacimiento" value="<?php echo $alumno->__GET('FechaNacimiento'); ?>" style="width:100%;" /></td>
                        </tr>
                        <tr>
                            <th style="text-align:left;">Fotografia</th>
                            <td><input type="file" name="fotografia" style="width:100%;" /></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center;padding:.2em;">
                                <button type="submit">Guardar</button>
                            </td>
                        </tr>
                    </table>
                </form>

                <table>
                    <thead>
                        <tr>
                            <th>Fotografia</th>
                            <th style="text-align:left;">Nombre</th>
                            <th style="text-align:left;">Apellido</th>
                            <th style="text-align:left;">Sexo</th>
                            <th style="text-align:left;">Nacimiento</th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                    <?php foreach ($modeloAlumno->Listar() as $r) : ?>
                        <tr>
                            <td style="text-align: center;padding:.2em;"><img src="assets/img/<?php echo $r->__GET('Fotografia') ?>" alt="Fotografia <?php echo $r->__GET('Nombre'); ?>" width="100"></td>
                            <td><?php echo $r->__GET('Nombre'); ?></td>
                            <td><?php echo $r->__GET('Apellido'); ?></td>
                            <td><?php echo $r->__GET('Sexo') == 1 ? 'H' : 'F'; ?></td>
                            <td><?php echo $r->__GET('FechaNacimiento'); ?></td>
                            <td>
                                <a href="?action=editar&id=<?php echo $r->id; ?>">Editar</a>
                            </td>
                            <td>
                                <a href="?action=eliminar&id=<?php echo $r->id; ?>&foto=<?php echo $r->__GET('Fotografia') ?>">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>

            </div>
        </main>

        <div>
            <a href="controlador/logout.php">Cerrar Sesion</a>
        </div>

        <hr>

        <footer class="pie">
            <p>Creado por mlizquierdos. Curso 2021/22</p>
        </footer>
    </div>
</body>

</html>