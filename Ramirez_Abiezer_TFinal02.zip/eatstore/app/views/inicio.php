        <h1>Nuestros Productos</h1>

        <div class="contenedor">
            <form action="#">
                <fieldset class="ui-widget">
                  <legend>Precio</legend>
                  <label for="precio">Mínimo y Máximo: </label>
                  <output id="precio"></output>
                  <p id="preciosMM"></p>
                </fieldset>
            </form>
        </div>

        <div class="grid">
            <!-- Aquí se colocan los productos <div class="producto"></div> -->
            <div class="grafico grafico--comida"></div>
            <div class="grafico grafico--node"></div>
        </div>