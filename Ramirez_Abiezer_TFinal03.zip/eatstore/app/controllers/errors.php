<?php
$message = array(
    'error' => array(
        1 => "Error, ya existe otro usuario con ese correo",
        2 => "Error, Campo requerido vacio al enviar el formulario",
        3 => "Error, Correo o contraseña incorrectos",
        4 => "Ciente no encontrado, no se han podido actualizar los datos",
        5 => "Error, DNI no valido",
        6 => "Error, correo electronico no valido",
        7 => "Error, ya existe un usuario registrado con ese DNI"

    ),
    'succes' => array(
        1 => "Registrado correctamente",
    )
);
