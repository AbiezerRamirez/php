<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="web/css/estilo.css" />
    <title>Inicio</title>
</head>
<body>

    <div style="text-align:center;">
        <img src="web/img/gse_multipart8536.png" alt="IESVenancioBlanco logo">
        <h1>Web de examen<br>¡Bienvenido a mi web!</h1>
        <h3> Salamanca, a  </h3>
    </div>
    
    
</body>
</html>
