    <h1>   </h1>
    <table border="1">
        <tr>
            <td>Energía</td>
            <td> </td>
        </tr>
        <tr>
            <td>Proteina</td>
            <td> </td>
        </tr>
        <tr>
            <td>Hidratos de Carbono</td>
            <td> </td>
        </tr>
        <tr>
            <td>Fibra</td>
            <td> </td>
        </tr>
        <tr>
            <td>Grasa total</td>
            <td> </td>
        </tr>
    </table>

