</div>

<div id="pie">
    <hr/>
    <div style="text-align:center;">DWES. Creado por "tu_nombre". Curso 2021/22</div>
</div>
</body>
</html>