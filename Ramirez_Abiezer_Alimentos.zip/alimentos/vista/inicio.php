    <div style="text-align:center;">
        <img src="web/img/gse_multipart8536.png" alt="IESVenancioBlanco logo">
        <h1>Web de examen<br>¡Bienvenido a mi web!</h1>
        <h3> Salamanca, a 29/11/2021</h3>
    </div>
